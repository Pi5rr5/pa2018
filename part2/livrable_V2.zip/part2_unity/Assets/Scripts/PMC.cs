﻿using UnityEngine;
using MathNet.Numerics.LinearAlgebra;
using MathNet.Numerics.LinearAlgebra.Double;

public class PMC : MonoBehaviour {

	private void Start () {
		
	}
}
